package com.example.moattravel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoattravelApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoattravelApplication.class, args);
	}

}
